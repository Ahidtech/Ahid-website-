var backToggle = document.getElementById("back");
function toggleProfile(){
    backToggle.addEventListener("click", function(){
    })
}